import numpy as np


def Prox(eta, threshold):
    # 计算平方根阈值
    sq_threshold = np.sqrt(2 * threshold)

    # 获取输入数组的大小
    n = eta.shape[0]

    # 初始化输出数组
    value = np.zeros(n)

    # 遍历输入数组的每个元素
    for i in range(n):
        if threshold <= 2:
            if 0 < eta[i] <=  threshold :
                value[i] = 0
            elif threshold < eta[i] <= 1 + threshold / 2:
                value[i] = eta[i] - threshold
            else:
                value[i] = eta[i]  # 这个分支在 threshold <= 2 的条件下其实是多余的，因为前面已经覆盖了所有情况
        else:
            if eta[i] >= sq_threshold:
                value[i] = eta[i]
            elif 0 < eta[i] < sq_threshold:
                value[i] = 0
            else:
                value[i] = eta[i]  # 同样，这个分支在 else 条件下也是多余的，因为 eta[i] <= 0 的情况已经被前面的条件排除了

    # 注意：在 MATLAB 中，value' 是将 value 数组转置为列向量。
    # 在 Python 中，NumPy 数组已经是一维的，所以我们不需要显式转置。
    # 如果需要返回一个列向量（即二维数组，其中第二维的大小为1），我们可以使用 value[:, np.newaxis] 或 value.reshape(-1, 1)。
    # 但在这个例子中，我们保持 value 为一维数组。

    return value

# 示例用法：
# eta = np.array([1.0, 1.5, 2.0, 2.5, -1.0, 0.0, 3.0])
# threshold = 2.0
# result = Prox(eta, threshold)
# print(result)