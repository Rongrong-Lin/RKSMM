import numpy as np
import pandas as pd


class DataSet():
    @classmethod
    def load(cls, file_path,name) -> np.ndarray:
        try:
            return np.array(pd.read_excel(f'{file_path}{name}.xlsx', header=None))
        except Exception as e:
            print(e)


class MNIST(DataSet):
    path = r'D:\PythonPrograms\smm-ramp\smm-ramp\train-images\train-images.idx3-ubyte'
    path_label = r'D:\PythonPrograms\smm-ramp\smm-ramp\train-images\train-labels.idx1-ubyte'
    @classmethod
    def create_data(cls):
        # 加载数据
        n = 1000  # 1000
        samples = cls.load_mnist_images(cls.path)
        samples_set = samples.reshape(-1, 28 * 28)  # 转置以匹配MATLAB的维度
        samples_label = cls.load_mnist_labels(cls.path_label)
        class1, class2 = 0, 1
        # 分离正负类
        pos_set = samples_set[samples_label == class1, :]
        # indices = np.where(samples_label == class1)[0]
        # pos_set = samples_label[indices, :]
        # indices = np.where(samples_label == class2)[0]
        neg_set = samples_set[samples_label == class2, :]

        # 标签
        pos_label = np.ones((pos_set.shape[0], 1))
        neg_label = -np.ones((neg_set.shape[0], 1))

        # # 随机索引
        np.random.seed(0)  # 为了结果可重复
        samindex1 = np.random.permutation(pos_set.shape[0])
        samindex2 = np.random.permutation(neg_set.shape[0])

        # 划分训练集和测试集
        train_set = np.vstack([pos_set[samindex1[:int(0.4 * n)], :], neg_set[samindex2[:int(0.4 * n)], :]])
        test_set = np.vstack(
            [pos_set[samindex1[int(0.4 * n):int(0.5 * n)], :], neg_set[samindex2[int(0.4 * n):int(0.5 * n)], :]])
        train_label = np.vstack([pos_label[samindex1[:int(0.4 * n)]], neg_label[samindex2[:int(0.4 * n)]]])
        test_label = np.vstack(
            [pos_label[samindex1[int(0.4 * n):int(0.5 * n)]], neg_label[samindex2[int(0.4 * n):int(0.5 * n)]]])
        train_set = train_set / 255
        test_set = test_set / 255
        train_set = train_set - train_set.mean(axis=0)  # min_max_normalize(train_set)
        test_set = test_set - test_set.mean(axis=0)  # min_max_normalize(test_set)

        #
        # excel_file_path = 'train_set.xlsx'
        # pd.DataFrame(train_set).to_excel(excel_file_path, index=False, header=False)
        # excel_file_path = 'test_set.xlsx'
        # pd.DataFrame(test_set).to_excel(excel_file_path, index=False, header=False)
        # excel_file_path = 'train_label.xlsx'
        # pd.DataFrame(train_label).to_excel(excel_file_path, index=False, header=False)
        # excel_file_path = 'test_label.xlsx'
        # pd.DataFrame(test_label).to_excel(excel_file_path, index=False, header=False)
    @classmethod
    def load_mnist_images(cls,path):
        with open(path, 'rb') as f:
            magic_number = int.from_bytes(f.read(4), 'big')
            number_of_images = int.from_bytes(f.read(4), 'big')
            rows = int.from_bytes(f.read(4), 'big')
            cols = int.from_bytes(f.read(4), 'big')
            image_size = rows * cols
            images = np.frombuffer(f.read(image_size * number_of_images), dtype=np.uint8).reshape(number_of_images, rows,
                                                                                                  cols)
        return images

    @classmethod
    def load_mnist_labels(cls,path):
        with open(path, 'rb') as f:
            magic_number = int.from_bytes(f.read(4), 'big')
            number_of_labels = int.from_bytes(f.read(4), 'big')
            labels = np.frombuffer(f.read(number_of_labels), dtype=np.uint8)
        return labels

