import os

import numpy as np
import time
import kernel
import prox
import pandas as pd
from scipy.linalg import solve
from utils import get_metrics,get_FSV


def standard_prox_ramp(eta: np.ndarray, threshold):
    #  eta[eta<=0] = eta
    eta[(eta > 0) & (eta < threshold)] = 0
    con = (threshold < eta) & (eta < 1 + threshold / 2)
    eta[con] = eta[con] - threshold
    return eta


def KSMM_ramploss(X_kernel, train_label, params):
    n = X_kernel.shape[0]
    C = params.C
    sigma = params.sigma
    iota = params.iota

    y = np.array(train_label).flatten()
    # y = train_label
    c = np.zeros(n)
    b = 0
    Lambda = np.random.rand(n) * 0.1414
    Max_iter = 200


    X_kernel = X_kernel / np.max(X_kernel)
    for i in range(Max_iter):
        eta = np.ones(n) - np.diag(y) @ (X_kernel @ c) - (b * y) - Lambda / sigma
        # u = prox.Prox(eta, C / sigma)
        u = prox.Prox_hlinge(eta, C / sigma)
        # u = standard_prox_ramp(eta, C / sigma)

        xi = np.ones(n) - u - b * y - Lambda / sigma
        C_A = np.eye(n) / sigma + X_kernel
        C_B = y * xi
        c = solve(C_A, C_B)  # 使用 scipy.linalg.solve 来求解线性系统

        r = np.ones(n) - u - np.diag(y) @ (X_kernel @ c) - Lambda / sigma
        b = (y @ r) / n

        w = u + np.diag(y) @ (X_kernel @ c) + (b * y) - np.ones(n)
        Lambda = Lambda + iota * sigma * w
        # Lambda[Lambda < 1 + (C / (sigma * 2))] = Lambda[Lambda < 1 + (C / (sigma * 2))] + iota * sigma * w
        # Lambda[Lambda >= 1 + (C / (sigma * 2))] = 0

        # print(f'第{i + 1}步迭代')
        train_label = train_label.reshape(-1)
        pred = np.sign(-X_kernel @ (Lambda * y) + b)
        met = get_metrics(train_label, pred)
        nsv = get_FSV(Lambda, C=C)

        print(f'iter:{i + 1}, accuracy_train: {met[0]}, f1_train: {met[1]}, auc_train: {met[2]},FSV: {nsv}')

    return Lambda, y, b
