import numpy as np
import math
from scipy.signal import convolve2d
from common import Params


def kernel(A, B, W, d1, d2, k1, k2):
    C = A * B
    matrix = C.reshape(k1, k2)

    Z = convolve2d(matrix, W, mode='valid', boundary='fill', fillvalue=0)

    value = np.sum(Z ** d1) ** d2

    return value


def create_kernel(data_set, params: Params):
    q = 4
    n = data_set.shape[0]
    w = lambda x: q - x
    W = np.zeros((2 * q - 1, 2 * q - 1))
    for i in range(2 * q - 1):
        for j in range(2 * q - 1):
            W[i, j] = w(max(abs(i - q + 1), abs(j - q + 1)))
    #

    X_kernel = np.zeros((n, n))

    for i in range(n):
        for j in range(n):
            X_kernel[i, j] = kernel(data_set[i], data_set[j], W, 2, 2, params.k1, params.k2)
    return X_kernel

def test_create_kernel(data_set, test_set, params: Params):
    q = 4
    n = data_set.shape[0]
    w = lambda x: q - x
    W = np.zeros((2 * q - 1, 2 * q - 1))
    for i in range(2 * q - 1):
        for j in range(2 * q - 1):
            W[i, j] = w(max(abs(i - q + 1), abs(j - q + 1)))
    m = test_set.shape[0]
    test_kernel = np.zeros((m, n))
    for j in range(m):
        for i in range(n):
            test_kernel[j, i] = kernel(data_set[i], test_set[j], W, 2, 2, params.k1, params.k2)
    return  test_kernel

def create_rbfkernel(data_set, params: Params):
    n = data_set.shape[0]
    X_kernel = np.zeros((n, n))
    m = data_set.shape[1]
    for i in range(n):
        for j in range(n):
            squared_diff = np.sum(data_set[i] ** 2) + np.sum(data_set[j] ** 2) - np.dot(data_set[i],data_set[j])
            X_kernel[i, j] = np.exp(-(1/(m*n)) * squared_diff)
    return X_kernel

def test_create_rbfkernel(data_set, test_set, params: Params):
    n = data_set.shape[0]
    m = test_set.shape[0]
    c = data_set.shape[1]
    test_kernel = np.zeros((m, n))
    for j in range(m):
        for i in range(n):
            squared_diff = np.sum(data_set[i] ** 2) + np.sum(data_set[j] ** 2) - np.dot(data_set[i],data_set[j])
            test_kernel[j, i] = np.exp(-(1/(c*n)) * squared_diff)
    return  test_kernel

def create_polykernel(data_set, params: Params):
    n = data_set.shape[0]
    X_kernel = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            A = data_set[i].reshape(params.k1, params.k2)
            B = data_set[j].reshape(params.k1, params.k2)
            C = np.dot(A.T,B) + np.eye(A.shape[1])
            X_kernel[i, j] = np.sum(C) ** 3
    return X_kernel

def test_create_polykernel(data_set, test_set, params: Params):
    n = data_set.shape[0]
    m = test_set.shape[0]
    test_kernel = np.zeros((m, n))
    for j in range(m):
        for i in range(n):
            A = data_set[i].reshape(params.k1, params.k2)
            B = data_set[j].reshape(params.k1, params.k2)
            C = np.dot(A.T, B) + np.eye(A.shape[1])
            test_kernel[j, i] = np.sum(C) ** 3
    return  test_kernel

def create_gaukernel(data_set, params: Params):
    q = 2
    n = data_set.shape[0]
    w = q-1
    W = np.zeros((2 * q - 1, 2 * q - 1))
    for i in range(2 * q - 1):
        for j in range(2 * q - 1):
            a = ((i-w)**2 + (j-w)**2)/2
            W[i, j] = math.exp(-a)

    W = W/np.sum(W)
    X_kernel = np.zeros((n, n))

    for i in range(n):
        for j in range(n):
            X_kernel[i, j] = kernel(data_set[i], data_set[j], W, 2, 2, params.k1, params.k2)
    return X_kernel

def test_create_gaukernel(data_set, test_set, params: Params):
    q = 2
    n = data_set.shape[0]
    w = q-1
    W = np.zeros((2 * q - 1, 2 * q - 1))
    for i in range(2 * q - 1):
        for j in range(2 * q - 1):
            a = ((i-w)**2 + (j-w)**2)/2
            W[i, j] = math.exp(-a)
    W = W/np.sum(W)
    m = test_set.shape[0]
    test_kernel = np.zeros((m, n))
    for j in range(m):
        for i in range(n):
            test_kernel[j, i] = kernel(data_set[i], test_set[j], W, 2, 2, params.k1, params.k2)
    return  test_kernel


