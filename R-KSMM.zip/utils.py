from sklearn.metrics import accuracy_score, f1_score, roc_auc_score


def get_FSV(Lambda, C):
    return ((Lambda > -C) & (Lambda < 0)).sum()


def get_metrics(y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    auc = roc_auc_score(y_true, y_pred)
    return acc, f1, auc
